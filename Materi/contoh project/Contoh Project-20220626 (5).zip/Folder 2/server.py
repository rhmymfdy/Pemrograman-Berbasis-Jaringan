from email import message
import time, socket, sys
from unicodedata import name
from xmlrpc.client import ProtocolError

print("\nSelamat bergabung pada Chatroom\n")
print("Inisialisasi...\n")
time.sleep(1)

s = socket.socket()
host = socket.gethostname()
ip = socket.gethostbyname(host)
Port = 1234
s.bind((ip, Port))
print(host, "(", ip, ")\n")
name = input(str("Masukkan username: "))

s.listen(1)
print("\nMenunggu koneksi masuk...\n")
conn, addr = s.accept()
print("Menerima koneksi dari ", addr[0], "(", addr[1], ")\n")

s_name = conn.recv(1024)
s_name = s_name.decode()
print(s_name, "Sudah terkoneksi kedalam chatroom\nKetik [e] untuk keluar dari chatroom\n")
conn.send(name.encode())

while True:
    message = input(str("Me: "))
    if message == "[e]":
        message = "Meninggalkan chatroom"
        conn.send(message.encode())
        print("\n")
        break
    conn.send(message.encode())
    message = conn.recv(1024)
    message = message.decode()
    print(s_name, ":", message)

