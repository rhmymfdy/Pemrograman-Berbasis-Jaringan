import socket      

#SOCK_DGRAM menggunakan UDP protocol
s = socket.socket(socket.AF_INET , socket.SOCK_DGRAM )

#binding IP dan port 
s.bind(("127.0.0.1", 2222))
print("Server dijalankan...127.0.0.1:2222")
print("Menunggu respon Client...") 

#menerima data dari client
while True:
    print(s.recvfrom(1024))