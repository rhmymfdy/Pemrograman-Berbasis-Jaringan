import socket

#membuat socket server
serverSocket = socket.socket()
print("Menjalankan socket server")

#asosiasi socket server dengan IP dan Port
ip = "127.0.0.1"
port = 35491
serverSocket.bind((ip, port))
print("Socket server terhubung dengan IP {} dan Port {}".format(ip, port))

#listening koneksi yang datang
serverSocket.listen()

#server incoming connection "satu per satu"
count = 0
while(True):
    (clientConnection, clientAddress) = serverSocket.accept()
    count += 1
    print("Menerima {} koneksi".format(count))
    #membaca koneksi dari client
    while(True):
        data = clientConnection.recv(1024)
        print(data)

        if(data!=b''):
            msg1 = "Hai Client, membaca permintaan client yang dikirim"
            msg1Btyes = str.encode(msg1)

            msg2 = "Server Menutup koneksi"
            msg2Btyes = str.encode(msg2)

            clientConnection.send(msg1Btyes)
            clientConnection.send(msg2Btyes)

            print("Koneksi ditutup")
            break

