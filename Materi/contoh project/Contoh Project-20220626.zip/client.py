#import modul socket
import socket
#membuat socket instance
socketObject = socket.socket()
#penggunaan socket untuk terkoneksi pada server
socketObject.connect(("localhost", 35491))
print("Terkoneksi pada server")
#mengirimkan pesan pada web server
HTTPMessage = "GET / HTTP/1.1\r\nHost: localhost\r\n Connection: close\r\n\r\n"
bytes = str.encode(HTTPMessage)

socketObject.sendall(bytes)

#penerimaan data
while(True):
    data = socketObject.recv(2048)
    print(data)

    if(data==b''):
        print("koneksi ditutup")
        break

socketObject.close()

